	<footer>
		<ul><li style = " background-color : lightgreen"><a href="Login.php">Log Out</a></li></ul>
        <hr><p><b>Department of Agriculture | Copyrights &copy; All Rights Reserved | Tel : 011 587 4256</b></p><hr>
    </footer>

</body>
</html>